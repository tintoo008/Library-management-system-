package exception;

/** Thrown when a book has no copies left to borrow. */
public class BookNotAvailableException extends LibraryException {
    private static final long serialVersionUID = 1L;

    public BookNotAvailableException(String title) {
        super("Book '" + title + "' is currently not available.");
    }
}
