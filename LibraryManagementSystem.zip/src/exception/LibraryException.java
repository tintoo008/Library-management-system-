package exception;

/** Base custom exception for all library related errors. */
public class LibraryException extends Exception {
    private static final long serialVersionUID = 1L;

    public LibraryException(String message) {
        super(message);
    }
}
