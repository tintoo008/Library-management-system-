package exception;

/** Thrown when a book, member or transaction cannot be found. */
public class RecordNotFoundException extends LibraryException {
    private static final long serialVersionUID = 1L;

    public RecordNotFoundException(String type, String id) {
        super(type + " with ID '" + id + "' was not found.");
    }
}
