package exception;

/** Thrown when a member tries to borrow more books than allowed. */
public class BorrowLimitExceededException extends LibraryException {
    private static final long serialVersionUID = 1L;

    public BorrowLimitExceededException(String memberName, int limit) {
        super(memberName + " has reached the borrowing limit of " + limit + " books.");
    }
}
