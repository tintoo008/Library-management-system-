package model;

import exception.BookNotAvailableException;

/** A book in the library. Holds the author by aggregation. */
public class Book {
    private String bookId;
    private String title;
    private Author author;
    private int totalCopies;
    private int availableCopies;

    public Book(String bookId, String title, Author author, int totalCopies) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.totalCopies = totalCopies;
        this.availableCopies = totalCopies;
    }

    public String getBookId() { return bookId; }
    public String getTitle() { return title; }
    public Author getAuthor() { return author; }
    public int getTotalCopies() { return totalCopies; }
    public int getAvailableCopies() { return availableCopies; }
    public boolean isAvailable() { return availableCopies > 0; }

    public void setTitle(String title) { this.title = title; }
    public void setAuthor(Author author) { this.author = author; }

    /** Reduces stock by one when a book is borrowed. */
    public void issueCopy() throws BookNotAvailableException {
        if (!isAvailable()) {
            throw new BookNotAvailableException(title);
        }
        availableCopies--;
    }

    /** Increases stock by one when a book is returned. */
    public void receiveCopy() {
        if (availableCopies < totalCopies) {
            availableCopies++;
        }
    }

    @Override
    public String toString() {
        return String.format("%-6s %-28s %-22s %5d / %-5d",
                bookId, title, author.getName(), availableCopies, totalCopies);
    }
}
