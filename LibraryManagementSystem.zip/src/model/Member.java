package model;

/** A regular library member. Subclasses override borrowing rules (polymorphism). */
public class Member {
    private String memberId;
    private String name;
    private String email;
    private int currentlyBorrowed;

    public Member(String memberId, String name, String email) {
        this.memberId = memberId;
        this.name = name;
        this.email = email;
        this.currentlyBorrowed = 0;
    }

    public String getMemberId() { return memberId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public int getCurrentlyBorrowed() { return currentlyBorrowed; }

    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }

    public void incrementBorrowed() { currentlyBorrowed++; }
    public void decrementBorrowed() { if (currentlyBorrowed > 0) currentlyBorrowed--; }

    /** Maximum books a member may hold at one time. */
    public int getMaxBooks() { return 3; }

    /** Number of days a book may be kept before it is overdue. */
    public int getLoanDays() { return 14; }

    /** Fine charged per day of delay. */
    public double getFinePerDay() { return 5.0; }

    public String getMemberType() { return "Regular"; }

    @Override
    public String toString() {
        return String.format("%-6s %-20s %-10s Borrowed: %d/%d",
                memberId, name, getMemberType(), currentlyBorrowed, getMaxBooks());
    }
}
