package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import exception.BookNotAvailableException;
import exception.BorrowLimitExceededException;
import exception.InvalidInputException;
import exception.RecordNotFoundException;

/** Core aggregate: the library owns books, members and transactions (composition). */
public class Library {
    private String name;
    private List<Book> books = new ArrayList<>();
    private List<Member> members = new ArrayList<>();
    private List<BorrowTransaction> borrowTransactions = new ArrayList<>();
    private List<ReturnTransaction> returnTransactions = new ArrayList<>();

    public Library(String name) {
        this.name = name;
    }

    public String getName() { return name; }

    public void addBook(Book book) throws InvalidInputException {
        for (Book b : books) {
            if (b.getBookId().equalsIgnoreCase(book.getBookId())) {
                throw new InvalidInputException("Book ID '" + book.getBookId() + "' already exists.");
            }
        }
        books.add(book);
    }

    public void addMember(Member member) throws InvalidInputException {
        for (Member m : members) {
            if (m.getMemberId().equalsIgnoreCase(member.getMemberId())) {
                throw new InvalidInputException("Member ID '" + member.getMemberId() + "' already exists.");
            }
        }
        members.add(member);
    }

    public Book findBook(String bookId) throws RecordNotFoundException {
        for (Book b : books) {
            if (b.getBookId().equalsIgnoreCase(bookId)) return b;
        }
        throw new RecordNotFoundException("Book", bookId);
    }

    public Member findMember(String memberId) throws RecordNotFoundException {
        for (Member m : members) {
            if (m.getMemberId().equalsIgnoreCase(memberId)) return m;
        }
        throw new RecordNotFoundException("Member", memberId);
    }

    public BorrowTransaction findActiveBorrow(String memberId, String bookId) throws RecordNotFoundException {
        for (BorrowTransaction t : borrowTransactions) {
            if (!t.isReturned()
                    && t.getMember().getMemberId().equalsIgnoreCase(memberId)
                    && t.getBook().getBookId().equalsIgnoreCase(bookId)) {
                return t;
            }
        }
        throw new RecordNotFoundException("Active borrow record for member " + memberId + " and book", bookId);
    }

    /** Borrow: checks stock and member limit, then reduces stock. */
    public BorrowTransaction borrowBook(String memberId, String bookId, LocalDate date)
            throws RecordNotFoundException, BookNotAvailableException, BorrowLimitExceededException {
        Member member = findMember(memberId);
        Book book = findBook(bookId);

        if (member.getCurrentlyBorrowed() >= member.getMaxBooks()) {
            throw new BorrowLimitExceededException(member.getName(), member.getMaxBooks());
        }
        book.issueCopy();               // throws if no stock
        member.incrementBorrowed();

        BorrowTransaction txn = new BorrowTransaction(book, member, date);
        borrowTransactions.add(txn);
        return txn;
    }

    /** Return: increases stock and calculates fine. */
    public ReturnTransaction returnBook(String memberId, String bookId, LocalDate date)
            throws RecordNotFoundException {
        BorrowTransaction borrow = findActiveBorrow(memberId, bookId);
        borrow.setReturned(true);
        borrow.getBook().receiveCopy();
        borrow.getMember().decrementBorrowed();

        ReturnTransaction ret = new ReturnTransaction(borrow, date);
        returnTransactions.add(ret);
        return ret;
    }

    public List<Book> getBooks() { return books; }
    public List<Member> getMembers() { return members; }
    public List<BorrowTransaction> getBorrowTransactions() { return borrowTransactions; }
    public List<ReturnTransaction> getReturnTransactions() { return returnTransactions; }
}
