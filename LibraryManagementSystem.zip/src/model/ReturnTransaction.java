package model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Records a book being returned and calculates any fine. */
public class ReturnTransaction {
    private static int counter = 5000;

    private String returnId;
    private BorrowTransaction borrowTransaction;
    private LocalDate returnDate;
    private long daysLate;
    private double fine;

    public ReturnTransaction(BorrowTransaction borrowTransaction, LocalDate returnDate) {
        this.returnId = "R" + (++counter);
        this.borrowTransaction = borrowTransaction;
        this.returnDate = returnDate;
        calculateFine();
    }

    private void calculateFine() {
        daysLate = ChronoUnit.DAYS.between(borrowTransaction.getDueDate(), returnDate);
        if (daysLate > 0) {
            fine = daysLate * borrowTransaction.getMember().getFinePerDay();
        } else {
            daysLate = 0;
            fine = 0.0;
        }
    }

    public String getReturnId() { return returnId; }
    public BorrowTransaction getBorrowTransaction() { return borrowTransaction; }
    public LocalDate getReturnDate() { return returnDate; }
    public long getDaysLate() { return daysLate; }
    public double getFine() { return fine; }

    public void printReceipt() {
        Member m = borrowTransaction.getMember();
        System.out.println("\n========== RETURN RECEIPT ==========");
        System.out.println("Return ID      : " + returnId);
        System.out.println("Borrow Txn ID  : " + borrowTransaction.getTransactionId());
        System.out.println("Member         : " + m.getName() + " (" + m.getMemberType() + ")");
        System.out.println("Book           : " + borrowTransaction.getBook().getTitle());
        System.out.println("Due Date       : " + borrowTransaction.getDueDate());
        System.out.println("Return Date    : " + returnDate);
        if (fine > 0) {
            System.out.println("Days Late      : " + daysLate);
            System.out.printf("Fine (Rs.%.2f/day): Rs.%.2f%n", m.getFinePerDay(), fine);
        } else {
            System.out.println("Fine           : Rs.0.00 (returned on time)");
        }
        System.out.println("====================================");
    }
}
