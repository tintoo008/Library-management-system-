package model;

import java.time.LocalDate;

/** Records a book being borrowed. Links directly to the book and member. */
public class BorrowTransaction {
    private static int counter = 1000;

    private String transactionId;
    private Book book;
    private Member member;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private boolean returned;

    public BorrowTransaction(Book book, Member member, LocalDate borrowDate) {
        this.transactionId = "B" + (++counter);
        this.book = book;
        this.member = member;
        this.borrowDate = borrowDate;
        this.dueDate = borrowDate.plusDays(member.getLoanDays());
        this.returned = false;
    }

    public String getTransactionId() { return transactionId; }
    public Book getBook() { return book; }
    public Member getMember() { return member; }
    public LocalDate getBorrowDate() { return borrowDate; }
    public LocalDate getDueDate() { return dueDate; }
    public boolean isReturned() { return returned; }
    public void setReturned(boolean returned) { this.returned = returned; }

    public void printReceipt() {
        System.out.println("\n========== BORROW RECEIPT ==========");
        System.out.println("Transaction ID : " + transactionId);
        System.out.println("Member         : " + member.getName() + " (" + member.getMemberType() + ")");
        System.out.println("Book           : " + book.getTitle());
        System.out.println("Borrow Date    : " + borrowDate);
        System.out.println("Due Date       : " + dueDate + " (" + member.getLoanDays() + " days)");
        System.out.println("====================================");
    }
}
