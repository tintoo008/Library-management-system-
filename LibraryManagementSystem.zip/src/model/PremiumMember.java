package model;

/** Premium member: more books, longer duration, lower fine. */
public class PremiumMember extends Member {

    public PremiumMember(String memberId, String name, String email) {
        super(memberId, name, email);
    }

    @Override
    public int getMaxBooks() { return 6; }

    @Override
    public int getLoanDays() { return 30; }

    @Override
    public double getFinePerDay() { return 2.0; }

    @Override
    public String getMemberType() { return "Premium"; }
}
