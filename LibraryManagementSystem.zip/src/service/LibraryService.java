package service;

import java.time.LocalDate;

import exception.InvalidInputException;
import exception.LibraryException;
import model.Author;
import model.Book;
import model.BorrowTransaction;
import model.Library;
import model.Member;
import model.PremiumMember;
import model.ReturnTransaction;

/** Service layer: bridges the menu and the Library model. */
public class LibraryService {
    private final Library library;

    public LibraryService(Library library) {
        this.library = library;
    }

    public void addBook(String id, String title, String authorName, String country, int copies)
            throws InvalidInputException {
        Book book = new Book(id, title, new Author(authorName, country), copies);
        library.addBook(book);
        System.out.println("Book added successfully: " + title);
    }

    public void addMember(String id, String name, String email, boolean premium)
            throws InvalidInputException {
        Member member = premium ? new PremiumMember(id, name, email) : new Member(id, name, email);
        library.addMember(member);
        System.out.println(member.getMemberType() + " member added successfully: " + name);
    }

    public void borrowBook(String memberId, String bookId, LocalDate date) throws LibraryException {
        BorrowTransaction txn = library.borrowBook(memberId, bookId, date);
        txn.printReceipt();
        showStock(txn.getBook());
    }

    public void returnBook(String memberId, String bookId, LocalDate date) throws LibraryException {
        ReturnTransaction ret = library.returnBook(memberId, bookId, date);
        ret.printReceipt();
        showStock(ret.getBorrowTransaction().getBook());
    }

    private void showStock(Book book) {
        System.out.println("Updated stock of '" + book.getTitle() + "': "
                + book.getAvailableCopies() + " of " + book.getTotalCopies() + " available.");
    }

    public void displayAvailableBooks() {
        System.out.println("\n------------------------ AVAILABLE BOOKS ------------------------");
        System.out.printf("%-6s %-28s %-22s %s%n", "ID", "Title", "Author", "Avail/Total");
        System.out.println("-----------------------------------------------------------------");
        boolean any = false;
        for (Book b : library.getBooks()) {
            if (b.isAvailable()) {
                System.out.println(b);
                any = true;
            }
        }
        if (!any) System.out.println("No books are currently available.");
        System.out.println("-----------------------------------------------------------------");
    }
}
