package main;

import java.util.Scanner;

import exception.InvalidInputException;
import exception.LibraryException;
import model.Library;
import service.LibraryService;
import util.InputHelper;

/**
 * Library Management System - Menu driven console application.
 * Name: Mounish Raj S S | Reg. No: 717825f232
 */
public class LibraryApp {

    private static void printMenu() {
        System.out.println("\n=========== LIBRARY MANAGEMENT SYSTEM ===========");
        System.out.println("1. Add Book");
        System.out.println("2. Add Member");
        System.out.println("3. Borrow Book");
        System.out.println("4. Return Book");
        System.out.println("5. Display Available Books");
        System.out.println("6. Exit");
        System.out.println("=================================================");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InputHelper in = new InputHelper(scanner);
        LibraryService service = new LibraryService(new Library("Central Library"));
        boolean running = true;

        while (running) {
            printMenu();
            try {
                int choice = in.readInt("Enter your choice (1-6): ", 1, 6);
                switch (choice) {
                    case 1: {
                        String id = in.readText("Book ID       : ");
                        String title = in.readText("Title         : ");
                        String author = in.readText("Author name   : ");
                        String country = in.readText("Author country: ");
                        int copies = in.readInt("No. of copies : ", 1, 1000);
                        service.addBook(id, title, author, country, copies);
                        break;
                    }
                    case 2: {
                        String id = in.readText("Member ID     : ");
                        String name = in.readText("Name          : ");
                        String email = in.readEmail("Email         : ");
                        int type = in.readInt("Type (1-Regular, 2-Premium): ", 1, 2);
                        service.addMember(id, name, email, type == 2);
                        break;
                    }
                    case 3: {
                        String mid = in.readText("Member ID     : ");
                        String bid = in.readText("Book ID       : ");
                        service.borrowBook(mid, bid,
                                in.readDate("Borrow date (yyyy-MM-dd, Enter = today): "));
                        break;
                    }
                    case 4: {
                        String mid = in.readText("Member ID     : ");
                        String bid = in.readText("Book ID       : ");
                        service.returnBook(mid, bid,
                                in.readDate("Return date (yyyy-MM-dd, Enter = today): "));
                        break;
                    }
                    case 5:
                        service.displayAvailableBooks();
                        break;
                    case 6:
                        System.out.println("Thank you for using the Library Management System. Goodbye!");
                        running = false;
                        break;
                    default:
                        break;
                }
            } catch (InvalidInputException e) {
                System.out.println("[Invalid Input] " + e.getMessage());
            } catch (LibraryException e) {
                System.out.println("[Error] " + e.getMessage());
            } catch (Exception e) {
                System.out.println("[Unexpected Error] " + e.getMessage());
            }
        }
        scanner.close();
    }
}
