package util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

import exception.InvalidInputException;

/** Reads and validates console input. */
public class InputHelper {
    private final Scanner scanner;

    public InputHelper(Scanner scanner) {
        this.scanner = scanner;
    }

    public String readText(String prompt) throws InvalidInputException {
        System.out.print(prompt);
        String value = scanner.nextLine().trim();
        if (value.isEmpty()) {
            throw new InvalidInputException("Input cannot be empty.");
        }
        return value;
    }

    public int readInt(String prompt, int min, int max) throws InvalidInputException {
        System.out.print(prompt);
        String line = scanner.nextLine().trim();
        try {
            int value = Integer.parseInt(line);
            if (value < min || value > max) {
                throw new InvalidInputException("Value must be between " + min + " and " + max + ".");
            }
            return value;
        } catch (NumberFormatException e) {
            throw new InvalidInputException("'" + line + "' is not a valid number.");
        }
    }

    public LocalDate readDate(String prompt) throws InvalidInputException {
        System.out.print(prompt);
        String line = scanner.nextLine().trim();
        if (line.isEmpty()) {
            return LocalDate.now();
        }
        try {
            return LocalDate.parse(line);
        } catch (DateTimeParseException e) {
            throw new InvalidInputException("Invalid date. Use format yyyy-MM-dd.");
        }
    }

    public String readEmail(String prompt) throws InvalidInputException {
        String email = readText(prompt);
        if (!email.matches("^[\\w.+-]+@[\\w-]+\\.[\\w.]+$")) {
            throw new InvalidInputException("Invalid email format.");
        }
        return email;
    }
}
