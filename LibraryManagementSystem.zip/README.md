# Library Management System (Java Console App)

**Name:** Mounish Raj S S  **Register No:** 717825f232
**Course:** 23CSR306 Java Programming - Assignment II (Specification 2)

## Problem Statement
Design and implement a Java console application for a Library Management System that manages books, members, borrowing, and returns. The system should follow object-oriented principles and ensure proper tracking of availability.

## How to compile and run
```
mkdir out
javac -d out $(find src -name "*.java")
java -cp out main.LibraryApp
```
(Or import the `src` folder into Eclipse and run `main/LibraryApp.java`.)
